import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.158.0/build/three.module.js';

const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
camera.position.z = 50;

const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(window.innerWidth, window.innerHeight);
document.body.appendChild(renderer.domElement);

window.addEventListener('resize', () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});

let objects = [];

document.getElementById('loadBtn').addEventListener('click', () => {
  fetch('sceneConfig.json')
    .then(res => res.json())
    .then(config => {
      objects.forEach(obj => scene.remove(obj));
      objects = loadSceneFromConfig(config, scene);
    });
});

function loadSceneFromConfig(config, scene) {
  scene.background = new THREE.Color(config.background);

  const ambient = new THREE.AmbientLight(config.lighting.ambient.color, config.lighting.ambient.intensity);
  const directional = new THREE.DirectionalLight(config.lighting.directional.color, config.lighting.directional.intensity);
  directional.position.set(...Object.values(config.lighting.directional.position));
  scene.add(ambient);
  scene.add(directional);

  return config.objects.map(objConfig => {
    const mesh = buildObjectFromConfig(objConfig);
    scene.add(mesh);
    return mesh;
  });
}

function buildObjectFromConfig(obj) {
  let geometry;
  if (obj.type === 'torusKnot') {
    geometry = new THREE.TorusKnotGeometry(
      obj.geometry.radius, obj.geometry.tube,
      obj.geometry.tubularSegments, obj.geometry.radialSegments,
      obj.geometry.p, obj.geometry.q
    );
  }

  const material = new THREE.MeshStandardMaterial({
    color: obj.material.color,
    metalness: obj.material.metalness,
    roughness: obj.material.roughness
  });

  const mesh = new THREE.Mesh(geometry, material);
  mesh.position.set(...Object.values(obj.transform.position));
  mesh.rotation.set(...Object.values(obj.transform.rotation));
  mesh.scale.set(...Object.values(obj.transform.scale));

  return mesh;
}

function animate() {
  requestAnimationFrame(animate);
  renderer.render(scene, camera);
}

animate();